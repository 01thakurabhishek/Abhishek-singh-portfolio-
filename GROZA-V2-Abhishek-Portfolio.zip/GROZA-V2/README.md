# GROZA V2 — Abhishek Singh Portfolio

## Preview
Open `index.html` in a modern browser with an internet connection. Three.js is loaded from jsDelivr.

## Run locally (recommended)
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Start a local server, for example with the VS Code Live Server extension, or run `python -m http.server 5500`.
4. Visit `http://localhost:5500`.

## Features
- Three.js WebGL particle portrait with a 78,000-particle target.
- Mouse-controlled 3D rotation and subtle idle motion.
- Reveal Photo / Back to Dots interaction.
- Responsive portfolio sections and downloadable resume.
- Uses the latest portrait supplied for this version.

## Notes
The particle field is generated in the browser from the supplied portrait. This is a 2.5D image-derived particle surface, not a photogrammetry scan or a watertight 3D head mesh. The Reveal button fades the particle field and reveals the original portrait. Three.js is fetched from a CDN, so the first load requires internet access.
